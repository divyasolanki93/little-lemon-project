import Header from '../components/Header';
import Footer from '../components/Footer';
import BookingForm from '../components/BookingForm';

export default function BookingPage() {
  return (
    <>
      <Header />
      <main>
        <h1>Book a Table</h1>
        <BookingForm />
      </main>
      <Footer />
    </>
  );
}
